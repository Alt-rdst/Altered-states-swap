import React from 'react';

export default function App() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Altered States Swap</h1>
      <p>This is your DEX front-end. Let’s wire it up!</p>
    </div>
  );
}
